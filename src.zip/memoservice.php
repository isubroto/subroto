<?php 
if(session_status()==PHP_SESSION_NONE){
    session_start();
}
require("database.php");
function optionvaluse($key,$val,$selected){
   if($selected){
    echo '<option selected value="'.$key.'">'.$val.'</option>';
   }
   else{
    echo ' <option value="'.$key.'">'.$val.'</option> ';
   }
}
function Adddokan(){
    if(isset($_REQUEST["name"]) && isset($_REQUEST["address"])){
        $db=new Database('localhost',"root","","test");
        $stutas=$db->insertDb("wholesale_customer",["Shop_Name"=>$_REQUEST["name"],"Shop_Address"=>$_REQUEST["address"],"Balance Amount"=>0]);
        if($stutas=="inserted"){
            echo 1;
        }
        else{
            echo 0;
        }

    }
}
function WholesaleCustomer(){
    $db=new Database('localhost',"root","","test");
    $data=$db->selectDbAsJson("wholesale_customer",["C_id","Shop_Name"]);
    $data=json_decode($data,true);
    echo '<option selected="" disabled="">দোকানের তালিকা</option><option value="লোকাল">লোকাল</option>';
    foreach ($data as $array){
        echo '<option value="'.$array["C_id"].'">'.$array["Shop_Name"].' </option> ';
    }
}
function LoadCompany(){
    $db=new Database('localhost',"root","","test");
    $data=$db->selectDbAsJson("company",["c_id","Company_name"]);
    $data=json_decode($data,true);
    
     if(isset($_REQUEST["companyid"])){
        echo "<option disabled>কোম্পানি</option>";
        foreach($data as $array){
            if($_REQUEST["companyid"]==$array["c_id"]){
                optionvaluse($array["c_id"],$array["Company_name"],true);
            }
            else{
                optionvaluse($array["c_id"],$array["Company_name"],false);
            }
        }
     }
     else{
        echo "<option selected disabled>কোম্পানি</option>";
        foreach($data as $array){
            optionvaluse($array["c_id"],$array["Company_name"],false);
        }
     }
}
function LoadMili(){
    $db=new Database('localhost',"root","","test");
    $data=$db->selectDbAsJson("thikness",["t_id","mm"],["c_id"=>$_REQUEST["companyid"]]);
    $data=json_decode($data,true);
     if(isset($_REQUEST["miliid"])){
        echo "<option selected >মিলি</option>";
         foreach($data as $array){
            if($_REQUEST["miliid"]==$array["t_id"]){
                optionvaluse($array["t_id"],$array["mm"],true);
             }
             else{
                optionvaluse($array["t_id"],$array["mm"],false);
             }
        }
     }
     else{
        echo "<option selected disabled >মিলি</option>";
        foreach($data as $array){
            optionvaluse($array["t_id"],$array["mm"],false);
        }
     }
}
function LoadFoot(){
    $db=new Database('localhost',"root","","test");
    $data=$db->selectDbAsJson("lenth",["l_id","length"],["t_id"=>$_REQUEST["miliid"]]);
    $data=json_decode($data,true);
     if(isset($_REQUEST["footid"])){
        echo "<option disabled>ফুট</option>";
        foreach($data as $array){
           if($_REQUEST["footid"]==$array["l_id"]){
            optionvaluse($array["l_id"],$array["length"],true);
           }
           else{
            optionvaluse($array["l_id"],$array["length"],false);
           }
        }
     }
     else
     {
        echo "<option selected disabled>ফুট</option>";
        foreach($data as $array){
            optionvaluse($array["l_id"],$array["length"],false);
        }
     }
}


function loadWholesaleCustomer(){
    $db=new Database('localhost',"root","","test");
    $data=$db->selectDbAsJson("wholesale_customer",["C_id","Shop_Name"]);
    $data=json_decode($data,true);
    echo '<option selected="" disabled="">দোকানের তালিকা</option>';
    foreach ($data as $array){
        echo '<option value="'.$array["C_id"].'">'.$array["Shop_Name"].' </option> ';
    }
}


if(isset($_REQUEST["func"]) && $_SESSION["loginstutas"]){
    switch ($_REQUEST["func"]) {
        case 'Adddokan':
            Adddokan();
            break;
            case 'WholesaleCustomer':
            WholesaleCustomer();
            break;
            case 'LoadCompany':
            LoadCompany();
            break;
            case 'LoadMili':
            LoadMili();
            break;
            case 'LoadFoot':
            LoadFoot();
            break;
            case 'loadWholesaleCustomer':
            loadWholesaleCustomer();
            break;
        
        default:
            # code...
            break;
    }
}
?>