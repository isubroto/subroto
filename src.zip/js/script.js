var finalEnlishToBanglaNumber={'0':'০','1':'১','2':'২','3':'৩','4':'৪','5':'৫','6':'৬','7':'৭','8':'৮','9':'৯'};
 
String.prototype.getDigitBanglaFromEnglish = function() {
    var retStr = this;
    for (var x in finalEnlishToBanglaNumber) {
         retStr = retStr.replace(new RegExp(x, 'g'), finalEnlishToBanglaNumber[x]);
    }
    return retStr;
};
  

  function addToDetails(array)
  {
    var loop='';
    var istotal=true;
    var total=0;
    var footer=null;
    if(array.length<=0)
    {
      $("#memodetails").html(" <h3 class='mt-5 d-flex justify-content-center'>কোন বিবরণ পাওয়া যায় নি।</h3>");
      $("#draftmemo").prop("disabled",true);
      $("#complitememo").prop("disabled",true);
    }
    else if(array.length>0){
      for(var i=0;i<array.length;i++)
      {
        if(array[i].Baseprice == null)
        {
          istotal=false;
          loop += "<div class='col-12'><div class='row p-2 pt-3'><div class='col-2 d-flex justify-content-center mt-1'><h6 class='tools' data-toggle='tooltip' title='"+array[i].Title.toString().getDigitBanglaFromEnglish()+"'><strong>"+array[i].Quantity.getDigitBanglaFromEnglish()+" পিছ</strong></h6></div><div class='col-4 d-flex justify-content-center mt-1'><h6><strong>"+array[i].Length.getDigitBanglaFromEnglish()+"x"+array[i].Thikness.getDigitBanglaFromEnglish()+"&nbsp;&nbsp;"+array[i].Company+"</strong></h6></div><div class='col-2 d-flex justify-content-center mt-1'><h6><strong></strong></h6></div><div class='col-3 d-flex justify-content-center mt-1'><h6><strong></strong></h6> </div> <div class='col-1 d-flex justify-content-center'><button type='button' onclick="+"Edit('"+array[i].Id+"')"+" class='btn btn-sm btn-outline-custom-blue mr-1'><i class='far fa-edit'></i></button><button type='button' onclick="+"Delete('"+array[i].Id+"')"+" class='btn btn-sm btn-outline-danger'><i class='far fa-trash-alt'></i></button></div></div></div>";
          $(".tools").tooltip({
            placement : 'left'
        });
        }
        else if(array[i].Baseprice != null)
        {
          loop += "<div class='col-12'><div class='row p-2 pt-3'><div class='col-2 d-flex justify-content-center mt-1'><h6 class='tools' data-toggle='tooltip' title='"+array[i].Title.toString().getDigitBanglaFromEnglish()+"'><strong>"+array[i].Quantity.getDigitBanglaFromEnglish()+" পিছ</strong></h6></div><div class='col-4 d-flex justify-content-center mt-1'><h6><strong>"+array[i].Length.getDigitBanglaFromEnglish()+"x"+array[i].Thikness.getDigitBanglaFromEnglish()+"&nbsp;&nbsp;"+array[i].Company+"</strong></h6></div><div class='col-2 d-flex justify-content-center mt-1'><h6><strong>"+array[i].Baseprice.getDigitBanglaFromEnglish()+"</strong></h6></div><div class='col-3 d-flex justify-content-center mt-1'><h6><strong>"+array[i].Totalprice.getDigitBanglaFromEnglish()+"  ৳</strong></h6> </div> <div class='col-1 d-flex justify-content-center'><button type='button' onclick="+"Edit('"+array[i].Id+"')"+" class='btn btn-sm btn-outline-custom-blue mr-1'><i class='far fa-edit'></i></button><button type='button' onclick="+"Delete('"+array[i].Id+"')"+" class='btn btn-sm btn-outline-danger'><i class='far fa-trash-alt'></i></button></div></div></div>";
          $(".tools").tooltip({
            placement : 'left'
        });
        }
      }
      

    if(istotal)
    {
      loop += "<div class='col-12'><div class='row p-2 pt-3 d-flex justify-content-end'><div class='col-3 d-flex justify-content-center mt-1'><h6><strong>লেবার</strong></h6></div><div class='col-3 d-flex justify-content-center'><input type='text' name='laberinput' id='laberinput' class='form-control'></div><div class='col-1 d-flex justify-content-center'><button type='button' class='btn btn-sm btn-outline-success' id='labercost'><i class='far fa-check-circle'></i> </button></div></div>"
      for(var i=0;i<array.length;i++)
      {
        total += parseInt(array[i].Totalprice);
      }
      footer="<div class='card-footer alert-danger d-flex justify-content-end'><div class='col-12 text-danger' id='footertotal'><div class='row p-2 d-flex justify-content-end'><div class='col-4 d-flex justify-content-center mt-1'><h6><strong>মোট = </strong></h6></div><div class='col-3 d-flex justify-content-center' id='totalprice'><h6><strong>"+(total.toString()).getDigitBanglaFromEnglish()+"  ৳</strong></h6></div></div></div></div>";
      $("#complitememo").prop('disabled', false);
      $("#labercost").prop('disabled', false);
      $("#draftmemo").prop('disabled', false);
      $(".tools").tooltip({
        placement : 'left'
    });
    }
    else if(!istotal)
    {
      loop += "<div class='col-12'><div class='row p-2 pt-3 d-flex justify-content-end'><div class='col-3 d-flex justify-content-center mt-1'><h6><strong>লেবার</strong></h6></div><div class='col-3 d-flex justify-content-center'><input type='text' name='laberinput' id='laberinput' class='form-control'></div><div class='col-1 d-flex justify-content-center'><button type='button' class='btn btn-sm btn-outline-success' id='labercost' disabled><i class='far fa-check-circle'></i> </button></div></div>";
      footer="<div class='card-footer alert-danger d-flex justify-content-end'><div class='col-12 text-danger' id='footertotal'><div class='row p-2 d-flex justify-content-end'><div class='col-4 d-flex justify-content-center mt-1'><h6><strong>মোট = </strong></h6></div><div class='col-3 d-flex justify-content-center' id='totalprice'><h6><strong></strong></h6></div></div></div></div>";
      $("#complitememo").prop('disabled', true);
      $("#labercost").prop('disabled', true);
      $("#draftmemo").prop('disabled', false);
      $(".tools").tooltip({
        placement : 'left'
    });
    }

      $("#memodetails").html(" <div class='card mt-3'><div class='card-header bg-danger text-white'><div class='row pt-2'><div class='col-2 d-flex justify-content-center'><h6><strong>পরিমাণ</strong></h6></div><div class='col-4 d-flex justify-content-center'><h6><strong>বিবরণ</strong></h6></div><div class='col-2 d-flex justify-content-center'><h6><strong>দর</strong></h6></div><div class='col-3 d-flex justify-content-center'><h6><strong>টাকা</strong></h6></div></div></div><div class='card-body'><div class='row d-flex justify-content-around' ><div class='col-11'></div> "+loop+footer);
      $(".tools").tooltip({
        placement : 'left'
    });
    }
    $(".tools").tooltip({
      placement : 'left'
  });
  }
  
   function totalWithLaber(array){
    var totalval=true;
    var totalprice=0;
    var laber=0;
    for( var i=0;i<array.length;i++){
      if(array[i].Baseprice==null)
      {
        totalval=false;
        $("#totalprice").html('');
      }
      else
      {
        continue;
      }
    }
    if(totalval)
    {
      for(var i =0;i<array.length;i++)
    {
      totalprice += parseInt(array[i].Totalprice);
    }
   
  if($("#laberinput").val()!='' && $("#laberinput").val()!=null){
      laber= parseInt($("#laberinput").val());
      $("#totalprice").html("<h6><b><strong>"+(totalprice+laber).toString().getDigitBanglaFromEnglish()+" ৳</strong></b></h6>");
    }
    else  if($("#laberinput").val()=='' || $("#laberinput").val()==null)
    {
      $("#totalprice").html("<h6><b><strong>"+totalprice.toString().getDigitBanglaFromEnglish()+" ৳</strong></b></h6>");
    }
    }
    }
  
    function addDetailstodb(id,array){
      $.post("draftmemooperation.php",{func:"getcustomerdraftmemo",customerId:id},"JSON").done(function(data){
        for(var i=0;i<array.length;i++){
          if(array[i].Baseprice==null){
            $.post("draftmemooperation.php",{func:"addcustomerdraftmemodetails",DM_Id:data,C_Id:array[i].CompanyId,T_Id:array[i].ThiknessId,I_Id:array[i].LengthId,Quantity:array[i].Quantity,baseprice:null},"JSON").done(function(data1){
            });
          }
          else if(array[i].Baseprice!=null){
            $.post("draftmemooperation.php",{func:"addcustomerdraftmemodetails",DM_Id:data,C_Id:array[i].CompanyId,T_Id:array[i].ThiknessId,I_Id:array[i].LengthId,Quantity:array[i].Quantity,baseprice:array[i].Baseprice},"JSON").done(function(data1){
            });
          }
        }
      });
    }