<?php 
if(session_status()==PHP_SESSION_NONE){
    session_start();
}
if(!isset($_SESSION["loginstutas"])||$_SESSION["loginstutas"]!=1)
    {
        header("Location:login.city");
    } 
    else{  
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ম্যামো</title>
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" href="customfonts/font.css">
    <link rel="stylesheet" href="css/style.css">
    <noscript>
        <style>
            div,nav,header{
            display: none;
                 }
            h2{
                position: fixed;
                color: red;
                font-size: 2.5rem;
                top:50%;
                left: 50%;
                transform: translate(-50%,-50%);
                border: 1px solid red;
                padding: 0 3rem;
                background-color: rgb(247, 165, 165);
                border-radius: 5px;
                box-shadow: 0 0 0 0.2rem rgb(250, 131, 131);
            }
        </style>
           <h2>enable java script to do operation</h2>
    </noscript>
</head>
<body >
<header>
    <nav class="navbar navbar-expand-md navbar-dark bg-dark" id="menubar">
        
        <a href="#" disabled class="navbar-brand">মেসার্স সিটি ট্রেডার্স</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
              <ul class="navbar-nav mr-auto">
                  
              </ul>
            <ul class="navbar-nav mr-auto menu">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">ম্যামো</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a href="#" class="dropdown-item memoactive">নতুন ম্যামো</a>
                    <a href="draftmemo.city" class="dropdown-item">অসমাপ্ত ম্যামো</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="stock.city">স্টক</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="accounts.city">একাউন্ট</a>
              </li>
            </ul>
            <ul class="nav">
                <li class="nav-item">
                    <?php 
                    if(isset($_SESSION["loginstutas"])&&$_SESSION["loginstutas"]==1){
                        ?><a href="#" id="logout" class="nav-link lnk"><i class="fad fa-sign-out-alt mr-1"></i>
                        লগআউট</a>
                        <?php
                    }
                    else{
                        ?><a href="#" id="login" class="nav-link lnk"><i class="fad fa-user-alt"></i>
                        লগইন</a>
                        <?php
                    }
                    ?>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link lnk">
                        <i class="fad fa-history"></i>
                    ইতিহাস
                    </a>
                </li>
            </ul>
          </div>
</nav>
</header>
    <div class="d-flex justify-content-center">
        <div class="row">
                <div class="container justify-content-center mt-5">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 mx-auto bg-white justify-content-center">
                            <div class="card" id="formdiv">
                                <div class="card-header justify-content-center bg-primary ">
                                    <h2 class="d-flex text-white justify-content-center mt-1">নতুন ম্যামো তৈরি করুন</h2>
                                </div>
                                <form action="#" class="col-md-10 col-sm-12 m-auto mt-2">
                                    <div class="input-group mt-5 mb-3">
                                        <select name="newmemo" id="newmemo" class="form-control">
                                            <option selected disabled>দোকানের তালিকা</option>
                                        </select>
                                        <div class="input-group-append">
                                            <button class="btn btn-warning" id="newdokan" data-toggle='modal' data-target='#dokanadd' type="button">নতুন দোকান</button>
                                        </div>
                                    </div>
                                    <input type="text" name="localname" id="localname" class="form-control" placeholder="কাস্টমারের নাম">
                                </form>
                                <form action="#" class=" form-inline justify-content-center">
                                    <div class="form-group my-4 mx-2">
                                        <input id="itemquantity" class="form-control" type="text" name="itemquantity" placeholder="পিছ">
                                    </div>
                                    <div class="form-group my-4 mx-2">
                                        <select name="company" id="company" class="form-control"> 
                                            <option selected disabled>কোম্পানি</option>
                                    </select>
                                    </div>
                                    <div class="form-group my-4 mx-2">
                                        <select name="itemthikness" id="itemthikness" class="form-control"> 
                                            <option selected disabled>মিলি</option>
                                    </select>
                                    </div>
                                    <div class="form-group my-4 mx-2">
                                        <select name="itemlength" id="itemlength" class="form-control"> 
                                            <option selected disabled>ফুট</option>
                                    </select>
                                    </div>
                                    <div class="form-group my-4 mx-2">
                                        <input id="baseprice" class="form-control" type="text" name="baseprice" placeholder="দর">
                                    </div>
                                    <br>
                                    <div class="d-flex col-12 justify-content-center ">
                                        <button type="button" id="clear" class="btn btn-danger mt-3 mx-2"><i class="far fa-trash-alt"></i>  মুছুন</button>
                                    <div id="cng"><button type="button" id="addcard" class="btn btn-success mt-3 mx-2"><i class="far fa-check-circle"></i>  যুক্ত করুন</button></div>
                                    </div>
                                    <span class="error-message d-flex justify-content-center mt-5" id="errormsg"></span>
                                </form>
                                <div class="modal fade animate__zoomIn" id="dokanadd">
                                    <div class="modal-dialog bg-light modal-lg rounded ">
                                        <div class=" modal-content p-3 rounded">
                                            <div class="bordered rounded">
                                                <div class="modal-header justify-content-center bg-warning text-white">
                                                    <h3 class="modal-title justify-content-center">নতুন দোকান যুক্ত করুন</h3>
                                                    <button class="close" data-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body justify-content-center">
                                                        <div class="col-10 mx-auto justify-content-center">
                                                        <div class="input-group mt-4">
                                                            <div class="input-group-prepend">
                                                                <span class=" input-group-text">দোকানের নাম</span>
                                                            </div>
                                                            <input type="text" id="dokanname" class="form-control" placeholder="দোকানের নাম" >
                                                        </div>
                                                        <div class="input-group mt-4">
                                                            <div class="input-group-prepend">
                                                                <span class=" input-group-text">দোকানের ঠিকানা</span>
                                                            </div>
                                                            <input type="text" id="dokanaddress" class="form-control" placeholder="দোকানের ঠিকানা" >
                                                        </div>
                                                        </div>
                                                    <div class="modal-footer0 justify-content-center">
                                                        <button type="button" id="adddokantodb" class="btn btn-outline-warning mt-4 mr-3 ml-5">যুক্ত করুন</button>
                                                        <button type="button" class="btn btn-outline-danger mt-4 ml-3" data-dismiss="modal">বন্ধ করুন</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade animate__zoomIn mt-4" id="confirmdokan">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h3>নিশ্চিতকরন</h3>
                                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            </div>
                                            <div class="modal-body" id="confirmdokanbody">
                                            </div>
                                            <div class="modal-footer justify-content-center">
                                                <button type="button" id="addtodb" class="btn btn-outline-success px-2 mx-2">হ্যাঁ</button>
                                                <button type="button" class="btn btn-outline-danger px-2 mx-2" data-dismiss="modal">না</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                <div class="container justify-content-center mt-5">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 mx-auto bg-white justify-content-center">
                            <div class="card">
                                <div class="card-header text-white bg-success">
                                    <h2 class="d-flex justify-content-center">ম্যামো বিবরণ
                                    </h2>
                                </div>
                                <div class="card-body" id="memodetails"> 
                                    <h3 class='mt-5 d-flex justify-content-center'>কোন বিবরণ পাওয়া যায় নি।</h3>
                                </div>
                                <div class="row my-4">
                                    <div class="col-12 d-flex justify-content-center">
                                        <div class="col-6 d-flex justify-content-center">
                                            <button type="button" id="draftmemo" class=" btn btn-warning text-white mx-5" disabled><i class="far fa-save"></i> অসমাপ্ত রাখুন</button>
                                            <button type="button" id="complitememo" class=" btn btn-primary mx-5" disabled><i class="fas fa-check-double"></i> সম্পন্ন</button>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/all.js"></script>
    <script src="js/script.js"></script>
    <script src="js/linq.min.js"></script>
    <script>
        var orderlist=Array();
        $(document).ready(function(){
            $("#localname").hide();
            $("#newmemo").change(function(){
                if($(this).find(":selected").text()=='লোকাল')
                {
                    $("#localname").show();
                }
                if($(this).find(":selected").text()!='লোকাল')
                {
                    $("#localname").hide();
                }
            });
            $("#clear").click(function(){
                $("#itemquantity").val(null);
                $("#itemlength").prop('selectedIndex',0);
                $("#newmemo").prop('selectedIndex',0);
                $("#itemthikness").prop('selectedIndex',0);
                $("#company").prop('selectedIndex',0);
                $("#baseprice").val(null);
                $("#itemthikness").removeClass("error-message-report");
                $("#company").removeClass("error-message-report");
                $("#itemlength").removeClass("error-message-report");
                $("#itemquantity").removeClass("error-message-report");
                $("#newmemo").removeClass("error-message-report");
                $("#errormsg").html("");

            });
            $("#clearlst").click(function(){
                $("#incomplitememo").prop('selectedIndex',0);
            });
            $("#company").change(function(){
                $.post("memoservice.php",{func:"LoadMili",companyid:$("#company").find(":selected").val()},"HTML").done(function(data){
                    if(data!=null){
                        $("#itemthikness").html(data);
                    }
                    else {
                        alert("Server Problem");
                    }
                 });
            })
            $("#itemthikness").change(function(){
                $.post("memoservice.php",{func:"LoadFoot",miliid:$("#itemthikness").find(":selected").val()},"HTML").done(function(data){
                    if(data!=null){
                        $("#itemlength").html(data);
                    }
                    else {
                        alert("Server Problem");
                    }
                 });
            })
        });
$(document).ready(function () {
  $("#itemquantity").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                  return false;
    }
   });
  $("#baseprice").keypress(function (e) {
     if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                  return false;
    }
   });
});
$(document).on("keypress","input[type='text']#laberinput",function(e){
    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                  return false;
    }
});
$(document).on("click","button#labercost",function(){
    totalWithLaber(orderlist);
});
$(document).on("click","button#addcard",function(){
        verifybeforeadd();   
});
$(document).on("click","a#logout",function(){
    $.ajax({
                url:"logincheck.php",
                method:"POST",
                data:{func:"logout"},
                dataType:"JSON",
                success:function(data){
                        if(!data){
                            window.location.replace("login.city");
                        }
                }
            });
})
function Delete(id){
    var enumerable = Enumerable.From(orderlist);
    var dictionary = enumerable.ToDictionary();
    dictionary.Remove(enumerable.Single(s=>s.Id === id ));
    orderlist=dictionary.ToEnumerable().Select(s => s.Key).ToArray();
    addToDetails(orderlist);
}
function Edit(id){
    var enumerable = Enumerable.From(orderlist);
    var dictionary = enumerable.ToDictionary();
    var datajson=dictionary.Get(enumerable.Single(s=>s.Id === id));
    $.post("memoservice.php",{func:"LoadCompany",companyid:datajson.CompanyId},"HTML").done(function(data){
        if(data!=null){
            $("#company").html(data);
        }
        else {
            alert("Server Problem");
        }
    });
    $.post("memoservice.php",{func:"LoadMili",companyid:datajson.CompanyId,miliid:datajson.ThiknessId},"HTML").done(function(data){
            if(data!=null){
                $("#itemthikness").html(data);
            }
            else {
                alert("Server Problem");
            }
            });
    $.post("memoservice.php",{func:"LoadFoot",miliid:datajson.ThiknessId,footid:datajson.LengthId},"HTML").done(function(data){
    if(data!=null){
        $("#itemlength").html(data);
    }
    else {
        alert("Server Problem");
    }
    });
    $("#itemquantity").val(datajson.Quantity);
    $("#baseprice").val(datajson.Baseprice);
            $("#cng").html('<button type="button" onclick="Update('+"'"+datajson.Id+"'"+')" class="btn btn-custom-blue mt-3 mx-2"><i class="far fa-cloud-upload-alt"></i> পরিবর্তন করুন</button>')
    
}
$(document).on("click","button#newdokan",function(){
    $("#dokanname").val('');
    $("#dokanaddress").val('');
})
$(document).on("click","button#adddokantodb",function(){
    if($.trim($("#dokanname").val())==''){
        $("#dokanname").focus();
    }
    else if($.trim($("#dokanaddress").val())==''){
        $("#dokanaddress").focus();
    }
    else{
        var name=$("#dokanname").val();
    var address=$("#dokanaddress").val();
    $("#confirmdokanbody").html("<h4>দোকানের নাম : <strong class='text-custom-green'>"+name+"</strong><br>দোকানের ঠিকানা : <strong class='text-custom-green'>"+address+"</strong><h4>")
    $("#confirmdokan").modal({show:true});
    }
})
$(document).on("click","button#addtodb",function(){
    $.post("memoservice.php",{func:"Adddokan",name:$("#dokanname").val(),address:$("#dokanaddress").val()},"JSON").done(function(data){
        if(data){
            alert("দোকান যুক্ত হয়েছে");
            $.post("memoservice.php",{func:"WholesaleCustomer"},"HTML").done(function(data){
        if(data!=null){
            $("#newmemo").html(data);
        }
        else {
            alert("Server Problem");
        }
    });
            $("#confirmdokan").modal("hide");
        $("#dokanadd").modal("hide");
        }
        else{
            alert("দোকান যুক্ত হয়নি");
        }
    });
});
$(document).ready(function(){
    $.post("memoservice.php",{func:"WholesaleCustomer"},"HTML").done(function(data){
        if(data!=null){
            $("#newmemo").html(data);
        }
        else {
            alert("Server Problem");
        }
    });
});
$(document).ready(function(){
    $.post("memoservice.php",{func:"LoadCompany"},"HTML").done(function(data){
        if(data!=null){
            $("#company").html(data);
        }
        else {
            alert("Server Problem");
        }
    });
});
function Update(id){
    var enumerable = Enumerable.From(orderlist);
    var dictionary = enumerable.ToDictionary();
    dictionary.Remove(enumerable.Single(s=>s.Id === id ));
    orderlist=dictionary.ToEnumerable().Select(s => s.Key).ToArray();
    if(verifybeforeadd()){
        $("#cng").html('<button type="button" id="addcard" class="btn btn-success mt-3 mx-2"><i class="far fa-check-circle"></i>  যুক্ত করুন</button>');
    }
}



function memo(){
    if($("#baseprice").val()=='')
            { var title=null;
                if($("#company").find(":selected").text()!='মটকা'){
                    if($("#itemlength").find(":selected").text()=='৬'){
                        if(parseInt($("#itemquantity").val())%12==0){
                            title=parseInt(parseInt($("#itemquantity").val())/12)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/12)+" বান "+ (parseInt($("#itemquantity").val())%12)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৭'){
                        if(parseInt($("#itemquantity").val())%10==0){
                            title=parseInt(parseInt($("#itemquantity").val())/10)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/10)+" বান "+ (parseInt($("#itemquantity").val())%10)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৮'){
                        if(parseInt($("#itemquantity").val())%9==0){
                            title=parseInt(parseInt($("#itemquantity").val())/9)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/9)+" বান "+ (parseInt($("#itemquantity").val())%9)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৯'){
                        if(parseInt($("#itemquantity").val())%8==0){
                            title=parseInt(parseInt($("#itemquantity").val())/8)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/8)+" বান "+ (parseInt($("#itemquantity").val())%8)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='১০'){
                        if(parseInt($("#itemquantity").val())%7==0){
                            title=parseInt(parseInt($("#itemquantity").val())/7)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/7)+" বান "+ (parseInt($("#itemquantity").val())%7)+ " পিছ";
                        }
                    }
                
                var value={LengthId:$("#itemlength").find(":selected").val(),Id:Math.random().toString(36), Quantity : $("#itemquantity").val(),Length : $("#itemlength").find(":selected").text(),Company : $("#company").find(":selected").text(), Thikness: $("#itemthikness").find(":selected").text(), Title:title,CompanyId: $("#company").find(":selected").val(),ThiknessId: $("#itemthikness").find(":selected").val()};
            }
                if($("#company").find(":selected").text()=='মটকা'){

                
                var value={LengthId:$("#itemlength").find(":selected").val(),Id:Math.random().toString(36), Quantity : $("#itemquantity").val(),Length : $("#itemlength").find(":selected").text(),Company : $("#company").find(":selected").text(), Thikness: $("#itemthikness").find(":selected").text()+" মটকা",CompanyId: $("#company").find(":selected").val(),ThiknessId: $("#itemthikness").find(":selected").val()};
            }
                orderlist.push(value);
                addToDetails(orderlist);
                $("#itemquantity").val(null);
                $("#company").prop('selectedIndex',0);
                $("#itemthikness").html('<option selected disabled>মিলি</option>');
                $("#itemlength").html('<option selected disabled>ফুট</option>');
                $("#baseprice").val(null);

            }
            if($("#baseprice").val()!='')
            {
                var total=null;
                var title=null;
                if($("#company").find(":selected").text()=='মটকা'){
                    total=(parseFloat($("#baseprice").val())*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                    var value={LengthId:$("#itemlength").find(":selected").val(),Id:Math.random().toString(36),Quantity : $("#itemquantity").val(),Length : $("#itemlength").find(":selected").text(),Company : $("#company").find(":selected").text(), Thikness: $("#itemthikness").find(":selected").text()+" মটকা",Baseprice: $("#baseprice").val(),Totalprice: total.toString(),CompanyId: $("#company").find(":selected").val(),ThiknessId: $("#itemthikness").find(":selected").val()};
                }
                else if($("#company").find(":selected").text()!='মটকা'){
                    if($("#itemlength").find(":selected").text()=='৬'){
                        if(parseInt($("#itemquantity").val())%12==0){
                            title=parseInt(parseInt($("#itemquantity").val())/12)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/12)+" বান "+ (parseInt($("#itemquantity").val())%12)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৭'){
                        if(parseInt($("#itemquantity").val())%10==0){
                            title=parseInt(parseInt($("#itemquantity").val())/10)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/10)+" বান "+ (parseInt($("#itemquantity").val())%10)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৮'){
                        if(parseInt($("#itemquantity").val())%9==0){
                            title=parseInt(parseInt($("#itemquantity").val())/9)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/9)+" বান "+ (parseInt($("#itemquantity").val())%9)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='৯'){
                        if(parseInt($("#itemquantity").val())%8==0){
                            title=parseInt(parseInt($("#itemquantity").val())/8)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/8)+" বান "+ (parseInt($("#itemquantity").val())%8)+ " পিছ";
                        }
                    }
                    else if($("#itemlength").find(":selected").text()=='১০'){
                        if(parseInt($("#itemquantity").val())%7==0){
                            title=parseInt(parseInt($("#itemquantity").val())/7)+" বান";
                        }
                        else{
                            title=parseInt(parseInt($("#itemquantity").val())/7)+" বান "+ (parseInt($("#itemquantity").val())%7)+ " পিছ";
                        }
                    }


                    if($("#itemlength").find(":selected").text()=='৬')
                {
                    total=((parseFloat($("#baseprice").val())/12)*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                }
                else if($("#itemlength").find(":selected").text()=='৭'){
                    total=((parseFloat($("#baseprice").val())/10)*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                }
                else if($("#itemlength").find(":selected").text()=='৮'){
                    total=((parseFloat($("#baseprice").val())/9)*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                }
                else if($("#itemlength").find(":selected").text()=='৯'){
                    total=((parseFloat($("#baseprice").val())/8)*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                }
                else if($("#itemlength").find(":selected").text()=='১০'){
                    total=((parseFloat($("#baseprice").val())/7)*parseFloat($("#itemquantity").val()));
                    total=Math.round(total);
                }
                var value={LengthId:$("#itemlength").find(":selected").val(),Id:Math.random().toString(36),Quantity : $("#itemquantity").val(),Length : $("#itemlength").find(":selected").text(),Company : $("#company").find(":selected").text(), Thikness: $("#itemthikness").find(":selected").text(),Baseprice: $("#baseprice").val(),Totalprice: total.toString(),Title:title,CompanyId: $("#company").find(":selected").val(),ThiknessId: $("#itemthikness").find(":selected").val()};
                }

               
                orderlist.push(value);
                addToDetails(orderlist);
                $("#itemquantity").val(null);
                $("#itemlength").prop('selectedIndex',0);
                $("#itemthikness").prop('selectedIndex',0);
                $("#company").prop('selectedIndex',0);
                $("#baseprice").val(null);
                $("#newmemo").removeClass("error-message-report");
                $("#itemquantity").removeClass("error-message-report");
                $("#company").removeClass("error-message-report");
                $("#itemthikness").removeClass("error-message-report");
                $("#itemlength").removeClass("error-message-report");
                $("#baseprice").removeClass("error-message-report");
                $("#localname").removeClass("error-message-report");
                $("#itemthikness").html('<option selected disabled>মিলি</option>');
                $("#itemlength").html('<option selected disabled>ফুট</option>');

            }
}
function verifybeforeadd(){
    var verified=false;
    if($("#newmemo").find(":selected").text()=='দোকানের তালিকা'){
            document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i> দোকানের তালিকা হতে দোকান বাছাই করুন";
            $("#newmemo").addClass("error-message-report");
            $("#newmemo").focus();
            setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else if($("#newmemo").find(":selected").text()!='সমূহের দোকানের তালিকা' && $("#newmemo").find(":selected").text()=='লোকাল' && $("#localname").val()==''){

                    document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i>  কাস্টমারের নাম লিখুন";
                    $("#localname").addClass("error-message-report");
                    $("#newmemo").removeClass("error-message-report");
                    $("#localname").focus();
                    setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else if($("#itemquantity").val()=='')
        {
            document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i>  পিছ সংখ্যা উল্লেখ করুন";
            $("#itemquantity").addClass("error-message-report");
            $("#newmemo").removeClass("error-message-report");
            $("#itemquantity").focus();
            setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else if($("#company").find(":selected").text()=='কোম্পানি')
        {
            document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i> কোম্পানি উল্লেখ করুন";
            $("#company").addClass("error-message-report");
            $("#itemlength").removeClass("error-message-report");
            $("#itemquantity").removeClass("error-message-report");
            $("#newmemo").removeClass("error-message-report");
            $("#company").focus();
            setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else if($("#itemthikness").find(":selected").text()=='মিলি')
        {
            document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i> মিলি সংখ্যা উল্লেখ করুন";
            $("#itemthikness").addClass("error-message-report");
            $("#company").removeClass("error-message-report");
            $("#itemlength").removeClass("error-message-report");
            $("#itemquantity").removeClass("error-message-report");
            $("#newmemo").removeClass("error-message-report");
            $("#itemthikness").focus();
            setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else if($("#itemlength").find(":selected").text()=='ফুট')
        {
            document.getElementById("errormsg").innerHTML = "<i class='fad fa-exclamation-circle ml-3 mr-1'></i> ফুট উল্লেখ করুন";
            $("#itemlength").addClass("error-message-report");
            $("#itemquantity").removeClass("error-message-report");
            $("#newmemo").removeClass("error-message-report");
            $("#itemlength").focus();
            setTimeout(function(){ 
                $("#errormsg").html('');
            }, 5000);
        }
        else{
            memo();
            verified=true;
        }
        return verified;
}
$(document).on("click","button#draftmemo",function(){
    $.post("draftmemooperation.php",{func:"findcustomerdraftmemo",customerId:$("#newmemo").find(":selected").val()},"JSON").done(function(dt){
        if(dt==1){
            $.post("draftmemooperation.php",{func:"addcustomerdraftmemo",customerId:$("#newmemo").find(":selected").val()},"JSON").done(function(data){
        if(data){
            addDetailstodb($("#newmemo").find(":selected").val(),orderlist);
            alert("ম্যামো অসমাপ্ত হিসেবে যুক্ত হয়েছে");
            orderlist=Array();
            $("#itemquantity").val(null);
            $("#itemlength").prop('selectedIndex',0);
            $("#newmemo").prop('selectedIndex',0);
            $("#itemthikness").prop('selectedIndex',0);
            $("#company").prop('selectedIndex',0);
            $("#baseprice").val(null);
            $("#itemthikness").removeClass("error-message-report");
            $("#company").removeClass("error-message-report");
            $("#itemlength").removeClass("error-message-report");
            $("#itemquantity").removeClass("error-message-report");
            $("#newmemo").removeClass("error-message-report");
            $("#errormsg").html("");
            addToDetails(orderlist);
        }
        else{
            alert(data);
        }
    });
        }
        else{
            alert("ম্যামো অসমাপ্ত হিসেবে রয়েছে অসমাপ্ত ম্যামো তে পাওয়া যাবে");
        }
    })
});
    </script>
</body>
</html>
<?php }?>
